#ifndef INCLUDED_AOSModule_SAMPLEMODULE_HPP_
#define INCLUDED_AOSModule_SAMPLEMODULE_HPP_

#include "apiAOS_SAMPLEPROJECT.hpp"

class AOS_SAMPLEPROJECTUPPERCASE_API AOSModule_SAMPLEMODULE : public AOSModuleInterface
{
public:
  AOSModule_SAMPLEMODULE(ALog&);
  virtual bool execute(AOSContext&, const AXmlElement&);
  
  /*!
  AOSAdminInterface
  */
  virtual const AString& getClass() const;
};

#endif //INCLUDED_AOSModule_classified_input_HPP_
