CREATE TABLE [session] (
[id] VARCHAR(48)  UNIQUE NOT NULL,
[data] TEXT  NULL
)