CREATE TABLE [user] (
[id] INTEGER  PRIMARY KEY NULL,
[username] TEXT  NULL,
[password] TEXT  NULL,
[data] TEXT  NULL
)